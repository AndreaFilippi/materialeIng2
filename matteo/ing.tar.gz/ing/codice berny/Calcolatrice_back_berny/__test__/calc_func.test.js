const root = process.env.SERVER_URL || 'http://127.0.0.1:3000'
const fetch = require("node-fetch")

const getSum = function (x, y) {
    return fetch(root+'/sum?x='+x+'&y='+y, {
        method: 'GET',
        headers: {
            'Accept': 'application/json'
        },
    })
}

const getMultiply = function (x, y) {
    return fetch(root+'/multiply?x='+x+'&y='+y, {
        method: 'GET',
        headers: {
            'Accept': 'application/json'
        },
    })
}


test('sum of two numbers', () => {
    return getSum(4,5)
        .then(response => {
            expect(response.status).toBe(200);
            return response.json();
        }).then(jsonresponse => {
            expect(jsonresponse.Risultato).toEqual(9)
        })
});

test('multiply of two numbers', () => {
    return getMultiply(4,5)
        .then(response => {
            expect(response.status).toBe(200);
            return response.json();
        }).then(jsonresponse => {
            expect(jsonresponse.Risultato).toEqual(20)
        })
});
