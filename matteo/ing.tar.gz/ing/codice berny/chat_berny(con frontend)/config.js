module.exports = {

    'secret': 'ilovescotchyscotch',
    'database': 'mongodb://localhost:27017/chat'

};