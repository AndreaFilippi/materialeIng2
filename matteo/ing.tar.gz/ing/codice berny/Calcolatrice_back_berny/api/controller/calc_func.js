exports.sum_calc = function(req, res){
    let sum = 0;
    sum = parseInt(req.query.x | 0) + parseInt(req.query.y | 0);
    res.json({"Risultato": sum});
}

exports.multiply_calc = function(req, res){
    let mult = 0;
    mult = parseInt(req.query.x | 0) * parseInt(req.query.y | 0);
    res.json({"Risultato": mult});
}