var express     = require('express');
var app         = express();
var controller = require('../controller/calc_func');

var appRouter = express.Router();

appRouter.get('/sum', controller.sum_calc);

appRouter.get('/multiply', controller.multiply_calc);

module.exports = appRouter;