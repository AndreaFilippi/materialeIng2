
var express = require('express');
var uuid = require('uuid-v4');
var bodyParser = require('body-parser');

var chat = express.Router();

/*
POST /user per registrarsi
GET /user/x per i dettagli dell'utente
PUT /user o /user/x per aggiornare l'utente
POST /room per creare una stanza
PUT /room per aggiornate il nome di una stanza
GET /rooms per una lista delle stanze
GET /msg?room=x?time=x per tutti i messaggi nella stanza specificata, dalla data speificata
POST /msg per scrivere un messaggio
*/

var userS = [];
var roomS = [];

chat.post('/user',function(req,resp){       //registrazione nuovo utente    
    var user = {};
    user.ID = uuid();
    user.nome = req.body.nome
    user.cognome = req.body.cognome
    user.email = req.body.email
    userS.push(user);

    resp.json(user);
});

chat.get('/user/:x',function(req,resp){       //info utente x dove x è ID

    var user = {};

    for(var i=0; i<userS.length; i++){
        if(userS[i].ID == req.params.x){
            user = userS[i];
        }
    }

    resp.json(user);
});

chat.put('/user/:x',function(req,resp){       //aggiorna utente x

    var user_pos;

    for(var i=0; i<userS.length; i++){
        if(userS[i].ID == req.params.x){
            user_pos = i;
        }
    }

    userS[user_pos].nome = req.body.nome;
    userS[user_pos].cognome = req.body.cognome;
    userS[user_pos].email = req.body.email;

    resp.json(userS[user_pos]);
});

chat.post('/room',function(req,resp){       //crea nuova room    
    var room =  {};
    room.ID = uuid();
    room.nome = req.body.nome;
    room.descrizione = req.body.descrizione;
    room.messaggi = [];

    roomS.push(room);

    resp.json(room)
});

chat.put('/room',function(req,resp){       //aggiorna nome room
    
});

chat.get('/rooms',function(req,resp){       //lista delle stanze
    resp.json(roomS);
});

chat.get('/msg',function(req,resp){       ///msg?room=x?time=x per tutti i messaggi nella stanza specificata, dalla data speificata

});

chat.post('/msg',function(req,resp){       //inviare un messaggio ad unsa stanza (stanza specificata nell'header)

//per mandare un messaggio : mando json nel body con ID_room: della stanza, ID_utente:id dell utente,descrizione:testo

    var room_pos;

    for(var i=0; i<roomS.length; i++){
        if(roomS[i].ID == req.body.ID_room){
            room_pos = i;
        }
    }

    if (room_pos != undefined){

        for(var i=0; i<userS.length; i++){
            if(userS[i].ID == req.body.ID_user){
                var messaggio = {};
                messaggio.ID_user = req.body.ID_user;
                messaggio.descrizione = req.body.descrizione;
                roomS[room_pos].messaggi.push(messaggio);
                resp.json(roomS[room_pos]);
            }
        }

    }else{
        resp.write('errore, room non trovata');
        resp.end();
    }

});



module.exports = chat;


